function calcularPedido() {


    let qtdTeclado = parseFloat(
        document.getElementById("qtdTeclado").value
    ) || 0;

    let precoTeclado = parseFloat(
        document.getElementById("precoTeclado").innerText.replace(",", ".")
    ) || 0;

    let subtotalTeclado = qtdTeclado * precoTeclado;

    document.getElementById("subtotalTeclado").innerText =
        subtotalTeclado.toFixed(2).replace(".", ",");


    let qtdMouse = parseFloat(
        document.getElementById("qtdMouse").value
    ) || 0;

    let precoMouse = parseFloat(
        document.getElementById("precoMouse").innerText.replace(",", ".")
    ) || 0;

    let subtotalMouse = qtdMouse * precoMouse;

    document.getElementById("subtotalMouse").innerText =
        subtotalMouse.toFixed(2).replace(".", ",");

    let qtdFone = parseFloat(
        document.getElementById("qtdFone").value
    ) || 0;

    let precoFone = parseFloat(
        document.getElementById("precoFone").innerText.replace(",", ".")
    ) || 0;

    let subtotalFone = qtdFone * precoFone;

    document.getElementById("subtotalFone").innerText =
        subtotalFone.toFixed(2).replace(".", ",");


    let qtdControle = parseFloat(
        document.getElementById("qtdControle").value
    ) || 0;

    let precoControle = parseFloat(
        document.getElementById("precoControle").innerText.replace(",", ".")
    ) || 0;

    let subtotalControle = qtdControle * precoControle;

    document.getElementById("subtotalControle").innerText =
        subtotalControle.toFixed(2).replace(".", ",");

    
    let precoCadeira  = parseFloat(
        document.getElementById("precoCadeira").innerText.replace(",", ".")
    ) || 0;

    let qtdCadeira = parseFloat(
        document.getElementById("qtdCadeira").value
    ) || 0;

    let subtotalCadeira = qtdCadeira * precoCadeira;

    document.getElementById("subtotalCadeira").innerText =
        subtotalCadeira.toFixed(2).replace(".", ",");


    let qtdNotebook = parseFloat(
        document.getElementById("qtdNotebook").value
    ) || 0;

    let precoNotebook = parseFloat(
        document.getElementById("precoNotebook").innerText.replace(",", ".")
    ) || 0;

    let subtotalNotebook = qtdNotebook * precoNotebook;

    document.getElementById("subtotalNotebook").innerText =
        subtotalNotebook.toFixed(2).replace(".", ",");

    let total =
        subtotalTeclado +
        subtotalMouse +
        subtotalFone +
        subtotalControle +
        subtotalCadeira +
        subtotalNotebook;

    document.getElementById("total").innerText =
        total.toFixed(2).replace(".", ",");
}